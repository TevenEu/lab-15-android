package ec.yachay.steeven.lab15;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.tensorflow.lite.Interpreter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SIZE = 28;
    private static final String[] LABELS = {"Normal", "Pneumonia"};
    private static final String[] CASES = {"case_01.png", "case_02.png", "case_03.png", "case_04.png"};
    private static final int INK = Color.rgb(19, 49, 58);
    private Interpreter classifier;
    private ImageView image;
    private TextView caseName;
    private TextView output;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(INK);
        getWindow().setNavigationBarColor(INK);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(235, 246, 243));
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(20), dp(18), dp(20), dp(18));
        scroll.addView(screen);
        screen.addView(text("Chest X-ray Classifier", 26));
        screen.addView(text("Steeven Eugenio · Lab 15", 15));

        caseName = text("", 16);
        caseName.setGravity(Gravity.CENTER);
        caseName.setPadding(0, dp(12), 0, dp(8));
        screen.addView(caseName);
        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setContentDescription("Selected chest radiograph");
        screen.addView(image, new LinearLayout.LayoutParams(-1, dp(200)));
        output = text("", 20);
        output.setGravity(Gravity.CENTER);
        output.setPadding(0, dp(14), 0, dp(10));
        screen.addView(output);

        LinearLayout buttons = new LinearLayout(this);
        screen.addView(buttons);
        for (int i = 0; i < CASES.length; i++) {
            final int index = i;
            Button button = new Button(this);
            button.setAllCaps(false);
            button.setText("Case " + (i + 1));
            button.setOnClickListener(v -> showCase(index));
            buttons.addView(button, new LinearLayout.LayoutParams(0, -2, 1));
        }
        TextView note = text("Educational demonstration", 13);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(10), 0, 0);
        screen.addView(note);
        setContentView(scroll);

        try {
            classifier = new Interpreter(loadModel(), new Interpreter.Options().setNumThreads(1));
            showCase(state == null ? 0 : state.getInt("selected"));
        } catch (IOException | RuntimeException e) {
            output.setText("Could not load the TensorFlow Lite model.");
        }
    }

    private int selected;

    @Override
    protected void onSaveInstanceState(Bundle state) {
        state.putInt("selected", selected);
        super.onSaveInstanceState(state);
    }

    private ByteBuffer loadModel() throws IOException {
        try (InputStream stream = getAssets().open("pneumonia.tflite");
             ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            for (int size; (size = stream.read(buffer)) != -1;) bytes.write(buffer, 0, size);
            ByteBuffer model = ByteBuffer.allocateDirect(bytes.size()).order(ByteOrder.nativeOrder());
            model.put(bytes.toByteArray());
            model.rewind();
            return model;
        }
    }

    private void showCase(int index) {
        if (classifier == null) return;
        selected = index;
        caseName.setText(CASES[index]);
        try (InputStream stream = getAssets().open(CASES[index])) {
            Bitmap bitmap = BitmapFactory.decodeStream(stream);
            if (bitmap == null || bitmap.getWidth() != SIZE || bitmap.getHeight() != SIZE) {
                throw new IOException("Expected a 28×28 PNG");
            }
            image.setImageBitmap(Bitmap.createScaledBitmap(bitmap, 280, 280, false));
            ByteBuffer input = ByteBuffer.allocateDirect(SIZE * SIZE * Float.BYTES).order(ByteOrder.nativeOrder());
            for (int y = 0; y < SIZE; y++) {
                for (int x = 0; x < SIZE; x++) input.putFloat(Color.red(bitmap.getPixel(x, y)) / 255.0f);
            }
            input.rewind();
            float[][] scores = new float[1][LABELS.length];
            classifier.run(input, scores);
            int best = scores[0][1] > scores[0][0] ? 1 : 0;
            output.setText(String.format(Locale.US, "%s · %.2f%%", LABELS[best], scores[0][best] * 100));
        } catch (IOException | RuntimeException e) {
            image.setImageDrawable(null);
            output.setText("Could not classify this image.");
        }
    }

    private TextView text(String value, int size) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(INK);
        return view;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (classifier != null) classifier.close();
        super.onDestroy();
    }
}
